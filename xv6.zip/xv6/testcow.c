#include "types.h"
#include "stat.h"
#include "user.h"

int i = 7;

int main(void)
{
   int pid;
   pid = fork();
   if(pid == 0)
   {
     printf(1,"Number of free pages in child 1 before changing variable are: %d\n", getNumFreePages());
     i = 9;
     printf(1,"Number of free pages in child 1 after changing variable due to copy are: %d\n", getNumFreePages());
  }
  else
  {
     wait();
     pid = fork();
     if(pid == 0)
     {
        printf(1,"Number of free pages in child 2 before changing variable are: %d\n", getNumFreePages());
         i = 9;
         printf(1,"Number of free pages in child 2 after changing variable due to copy are: %d\n", getNumFreePages());
     }
     else
     {
         wait();
         printf(1,"Number of free pages in parent are: %d\n", getNumFreePages());
         //wait();
      }
   }
   exit();
}
